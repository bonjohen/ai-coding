Claude Code Competence Level Icons v2

This second iteration uses a stronger progression model:
Level 1: direct terminal interaction
Level 2: structured exchange
Level 3: configured environment
Level 4: orchestrated workflow
Level 5: governed agentic system

All icons:
- 24x24 SVG
- transparent background
- circular outer form
- monochrome stroke design
- consistent visual weight
