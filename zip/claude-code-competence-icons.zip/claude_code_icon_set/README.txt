Claude Code Competence Icon Set

Contents
- 5 level icons
- 7 dimension icons

Path layout
- src/assets/icons/levels/
- src/assets/icons/dimensions/

All icons:
- are monochrome SVG
- use viewBox 0 0 24 24
- use stroke=currentColor
- are intended for 16px to 24px display sizes

Suggested CSS

.icon {
  width: 1.25rem;
  height: 1.25rem;
  display: inline-block;
  color: currentColor;
}

.level-1 { color: var(--level1); }
.level-2 { color: var(--level2); }
.level-3 { color: var(--level3); }
.level-4 { color: var(--level4); }
.level-5 { color: var(--level5); }
